#!/system/bin/sh
LOGDIR="/sdcard/TCP_Optimizer_Logs"
mkdir -p $LOGDIR
LOGFILE="$LOGDIR/tcp_opt.log"

echo "Starting AI-Based TCP Optimization..." >> $LOGFILE

# Detect Network Interface
NET_IF=$(ip route | grep default | awk '{print $5}')
if [ -z "$NET_IF" ]; then
  NET_IF=$(ls /sys/class/net | grep -E "rmnet|wlan" | head -n 1)
fi
echo "Detected Network Interface: $NET_IF" >> $LOGFILE

# Detect Network Type
if [[ "$NET_IF" == *"rmnet"* ]]; then
  NETWORK_TYPE="Mobile Data (4G/5G)"
elif [[ "$NET_IF" == *"wlan"* ]]; then
  NETWORK_TYPE="WiFi"
else
  NETWORK_TYPE="Unknown"
fi
echo "Network Type: $NETWORK_TYPE" >> $LOGFILE

# Get Available Congestion Control Algorithms
AVAILABLE_CC=$(sysctl -a 2>/dev/null | grep net.ipv4.tcp_available_congestion_control | awk -F ' = ' '{print $2}')
echo "Available Congestion Control: $AVAILABLE_CC" >> $LOGFILE

# AI-Based RTT Optimization
RTT=$(ping -c 1 8.8.8.8 | awk -F'/' 'END {print $5}')
echo "Current RTT: ${RTT}ms" >> $LOGFILE

if [ "$(echo "$RTT < 30" | bc -l)" -eq 1 ]; then
    OPTIMAL_CC="bbr"
elif [ "$(echo "$RTT < 100" | bc -l)" -eq 1 ]; then
    OPTIMAL_CC="cubic"
else
    OPTIMAL_CC="reno"
fi

# Apply Optimal TCP Congestion Control
if echo "$AVAILABLE_CC" | grep -q "$OPTIMAL_CC"; then
    sysctl -w net.ipv4.tcp_congestion_control=$OPTIMAL_CC && echo "Applied: $OPTIMAL_CC" >> $LOGFILE
else
    echo "Warning: $OPTIMAL_CC not supported, falling back to cubic" >> $LOGFILE
    sysctl -w net.ipv4.tcp_congestion_control=cubic
fi

# Battery-Aware Low Power Mode
BATTERY_LEVEL=$(dumpsys battery | grep level | awk '{print $2}')
echo "Battery Level: $BATTERY_LEVEL%" >> $LOGFILE

if [ "$BATTERY_LEVEL" -le 20 ]; then
    sysctl -w net.ipv4.tcp_slow_start_after_idle=1
    echo "Enabled Low Power Mode for TCP" >> $LOGFILE
fi
