#!/data/data/com.termux/files/usr/bin/bash

LOGFILE="$HOME/tcp_optimizer.log"
CONFIG_FILE="/data/local/tmp/tcp_config.cfg"

# Default RTT thresholds (user can modify these values)
LOW_RTT=50
MEDIUM_RTT=150

# Function to send toast notifications in Termux
send_notification() {
    termux-toast -b black -c green "$1"
    echo "$1" | tee -a $LOGFILE
}

# Function to detect network type
detect_network_type() {
    NET_IF=$(ip route | grep default | awk '{print $5}')
    if [[ "$NET_IF" == *"rmnet"* ]]; then
        echo "Mobile Data (4G/5G)"
    elif [[ "$NET_IF" == *"wlan"* ]]; then
        echo "WiFi"
    else
        echo "Unknown"
    fi
}

# Function to detect battery level
detect_battery_level() {
    dumpsys battery | grep level | awk '{print $2}'
}

# Function to apply TCP settings based on network type
apply_tcp_settings() {
    NETWORK_TYPE=$(detect_network_type)
    BATTERY_LEVEL=$(detect_battery_level)
    send_notification "Network: $NETWORK_TYPE | Battery: $BATTERY_LEVEL%"

    if [ "$BATTERY_LEVEL" -le 20 ]; then
        sysctl -w net.ipv4.tcp_congestion_control=reno
        sysctl -w net.ipv4.tcp_rmem="4096 87380 16777216"
        sysctl -w net.ipv4.tcp_wmem="4096 65536 16777216"
        send_notification "Low Battery Mode: Reno & lower buffers applied"
    elif [[ "$NETWORK_TYPE" == "Mobile Data (4G/5G)" ]]; then
        sysctl -w net.ipv4.tcp_congestion_control=reno
        sysctl -w net.ipv4.tcp_rmem="4096 87380 33554432"
        sysctl -w net.ipv4.tcp_wmem="4096 65536 33554432"
        send_notification "Mobile Data Optimized (Reno)"
    elif [[ "$NETWORK_TYPE" == "WiFi" ]]; then
        sysctl -w net.ipv4.tcp_congestion_control=cubic
        sysctl -w net.ipv4.tcp_rmem="4096 87380 67108864"
        sysctl -w net.ipv4.tcp_wmem="4096 65536 67108864"
        send_notification "WiFi Optimized (Cubic)"
    else
        send_notification "Unknown Network. No changes applied."
    fi
}

# Function to adjust settings based on RTT thresholds
adjust_based_on_rtt() {
    RTT=$(ping -c 1 8.8.8.8 | awk -F'/' 'END {print $5}')
    send_notification "Current RTT: ${RTT}ms"

    if [ "$(echo "$RTT < $LOW_RTT" | bc -l)" -eq 1 ]; then
        sysctl -w net.ipv4.tcp_rmem="4096 87380 67108864"
        sysctl -w net.ipv4.tcp_wmem="4096 65536 67108864"
        send_notification "Low RTT: High-performance mode enabled"
    elif [ "$(echo "$RTT < $MEDIUM_RTT" | bc -l)" -eq 1 ]; then
        sysctl -w net.ipv4.tcp_rmem="4096 87380 33554432"
        sysctl -w net.ipv4.tcp_wmem="4096 65536 33554432"
        send_notification "Medium RTT: Balanced mode applied"
    else
        sysctl -w net.ipv4.tcp_rmem="4096 87380 16777216"
        sysctl -w net.ipv4.tcp_wmem="4096 65536 16777216"
        send_notification "High RTT: Stability mode enabled"
    fi
}

# Function to start real-time monitoring loop
start_real_time_monitoring() {
    while true; do
        send_notification "Running AI-Based TCP Optimization..."
        apply_tcp_settings
        adjust_based_on_rtt
        send_notification "Sleeping for 5 minutes..."
        sleep 300  # Wait for 5 minutes before running again
    done
}

# Start the monitoring loop
start_real_time_monitoring
