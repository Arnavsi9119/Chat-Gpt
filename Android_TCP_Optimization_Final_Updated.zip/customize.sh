#!/system/bin/sh

CONFIG_FILE="/data/local/tmp/tcp_config.cfg"
LOG_FILE="/data/local/tmp/tcp_optimization.log"

# Function to log messages
log_message() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> "$LOG_FILE"
}

log_message "Starting TCP Optimization..."

# Load user config if exists
if [ -f "$CONFIG_FILE" ]; then
  source "$CONFIG_FILE"
  log_message "Loaded user configuration from $CONFIG_FILE"
else
  log_message "Configuration file not found. Using default settings."
  TCP_CONGESTION_CONTROL="cubic"
  TCP_INIT_CWND=25
  TCP_INIT_IRWND=25
  AI_TUNING="yes"
  LOW_POWER_MODE="auto"
fi

# Rootless mode check
if [ "$(id -u)" -ne 0 ]; then
  log_message "Root access not detected. Running in rootless mode. Exiting..."
  exit 1
fi

# Apply User Config Settings with error handling
apply_setting() {
  sysctl -w "$1"="$2" 2>>"$LOG_FILE" && log_message "Applied: $1=$2" || log_message "Failed: $1=$2"
}

apply_setting net.ipv4.tcp_congestion_control "$TCP_CONGESTION_CONTROL"

# AI-based Dynamic Tuning
if [ "$AI_TUNING" = "yes" ]; then
  SPEED=$(cat /sys/class/net/wlan0/speed 2>/dev/null || echo 0)
  LATENCY=$(ping -c 1 8.8.8.8 | awk -F'=' '/time=/{print $2}' | cut -d' ' -f1)

  if [ "$SPEED" -ge 100 ] && [ "$(echo "$LATENCY < 50" | bc)" -eq 1 ]; then
    apply_setting net.ipv4.tcp_window_scaling 1
    log_message "High-speed, low-latency mode applied"
  elif [ "$SPEED" -ge 50 ]; then
    apply_setting net.ipv4.tcp_window_scaling 0
    log_message "Medium-speed mode applied"
  else
    apply_setting net.ipv4.tcp_window_scaling 0
    log_message "Default mode applied"
  fi

  log_message "AI-Based Dynamic TCP Optimization Applied"
fi

# Low Power Mode Optimization
BATTERY_LEVEL=$(dumpsys battery | grep level | awk '{print $2}')
CHARGING_STATUS=$(dumpsys battery | grep AC-powered | awk '{print $2}')

if [ "$LOW_POWER_MODE" = "auto" ]; then
  if [ "$BATTERY_LEVEL" -le 20 ] && [ "$CHARGING_STATUS" -eq 0 ]; then
    apply_setting net.ipv4.tcp_slow_start_after_idle 1
    log_message "Low-Power Mode Activated"
  elif [ "$CHARGING_STATUS" -eq 1 ]; then
    apply_setting net.ipv4.tcp_slow_start_after_idle 0
    log_message "Charging detected, High-Performance Mode Activated"
  fi
fi

log_message "TCP Optimization Applied Successfully"
