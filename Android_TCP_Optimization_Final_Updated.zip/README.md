# Android TCP Optimization

## Description
Tuning the initcwnd and initrwnd parameters can have a significant improvement in TCP performance.
Resulting in faster web page downloads and faster connection between servers.

## Support
- [GitHub](https://github.com/LeanxModulostk/Android-TCP-Optimization) 
- [Telegram Channel](https://t.me/modulostk)

## Special Thanks

• [Zackptg5 for the MMT-Ex template](https://github.com/Zackptg5)

• [Topjohnwu for making Magisk](https://github.com/topjohnwu)